#include <cstdint>
#include <iostream>
#include <fstream>
#include <bitset>

#define LENGTH 1
#define MAXLEN 100
#define STUDENT_ID_SECRET 0xAA

int16_t lab1(int16_t n) {
    // initialize

    // calculation

    // return value
}

int16_t lab2(int16_t n) {
    // initialize

    // calculation

    // return value
}

int16_t lab3(char s1[], int n) {
    // initialize

    // calculation

    // return value
}


int16_t lab4(int16_t n) {
    // initialize

    // calculation

    // return value
}

int main() {
    std::fstream file;
    file.open("test.txt", std::ios::in);

    // lab1
    int16_t n = 0;
    std::cout << "===== lab1 =====" << std::endl;
    for (int i = 0; i < LENGTH; ++i) {
        file >> n;
        std::cout << lab1(n) << std::endl;
    }

    // lab2
    std::cout << "===== lab2 =====" << std::endl;
    for (int i = 0; i < LENGTH; ++i) {
        file >> n;
        std::cout << lab2(n) << std::endl;
    }

    // lab3
    std::cout << "===== lab3 =====" << std::endl;
    char s1[MAXLEN];
    for (int i = 0; i < LENGTH; ++i) {
        file >> s1 >> n;
        std::cout << lab3(s1, n) << std::endl;
    }
    
    // lab4
    std::cout << "===== lab4 =====" << std::endl;
    for (int i = 0; i < LENGTH; ++i) {
        file >> n ;
        std::cout << lab4(n) << std::endl;
    }
    
    file.close();
    return 0;
}